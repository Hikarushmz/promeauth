if (window.location.href === "https://j6.prometric-jp.com/Reserve/Status") {
    setTimeout(() => {
        const selBYear = document.querySelector('input[name="selBYear"]');
        const selBMonth = document.querySelector('input[name="selBMonth"]');
        const selBDay = document.querySelector('input[name="selBDay"]');
        const rdoGender = document.querySelector('input[name="rdoGender"][value="2"]');
        const selNation = document.querySelector('input[name="selNation"]');
        const selTraveling = document.querySelector('input[name="selTraveling"]');
        const selStudy = document.querySelector('input[name="selStudy"]');
        const selEng = document.querySelector('input[name="selEng"]');
        const selAgre = document.querySelector('input[name="selAgre"]');
        const selStatus = document.querySelector('input[name="selStatus"]');

        if (selBYear && selBMonth && selBDay && rdoGender && selNation && selTraveling && selStudy && selEng && selAgre && selStatus) {
            selBYear.value = "2003";
            selBMonth.value = "11";
            selBDay.value = "27";
            rdoGender.checked = true;
            selNation.value = "Indonesia";
            selTraveling.value = "Working";
            selStudy.value = "160 hours (approx. 4 hours a week for 10 months)";
            selEng.value = "None";
            selAgre.value = "Agree";
            selStatus.value = "I will not take the test in Japan.";

            const continueButton = document.querySelector('input[name="Continue"]');
            if (continueButton) {
                continueButton.click();
                alert("Formulir terisi dan dikirim.");
            }
        }
    }, 3000);
}
