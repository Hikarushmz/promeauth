document.getElementById('fillForm').addEventListener('click', () => {
    const formData = {
        selBYear: "2003",
        selBMonth: "11",
        selBDay: "27",
        rdoGender: "2", // 1 untuk perempuan, 2 untuk laki-laki
        selNation: "Indonesia",
        selTraveling: "Working",
        selStudy: "160 hours (approx. 4 hours a week for 10 months)",
        selEng: "None",
        selAgre: "Agree",
        selStatus: "I will not take the test in Japan."
    };

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: fillForm,
            args: [formData]
        });
    });
});

function fillForm(formData) {
    for (const [key, value] of Object.entries(formData)) {
        const element = document.querySelector(`[name='${key}']`);
        if (element) {
            if (element.tagName === "SELECT" || element.tagName === "INPUT") {
                element.value = value;
                element.dispatchEvent(new Event('change', { bubbles: true }));
            } else if (element.type === "radio") {
                document.querySelector(`[name='${key}'][value='${value}']`).checked = true;
            }
        }
    }
}
